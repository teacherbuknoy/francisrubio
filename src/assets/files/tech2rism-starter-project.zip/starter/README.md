# TECH2RISM Web development workshop starter files

This is the starter project you will use to create your own website. 

## How to use this starter project
1. A single webpage, `index.html`, is created for you. You can edit it as much as you like.
2. You also get a `layout.css` file that contains styles that were created in advance. This will help you design your website faster.

3. To add new CSS styles, create a new CSS file inside the `styles/` folder. Inside your HTML files, use the `<link>` tag to apply the styles, like this:

```html
<link rel="stylesheet" href="styles/[your CSS file]">
```

3. To add images, save your images to the `images/` folder. You can then use them in you webpage using the `<img>` tag like this:

```html
<img 
  src="images/[your image file name]" 
  alt="A short description of your image">
```

4. To create new pages for your website, create a new HTML file in the `pages/` folder. You can then use the `<a>` tag to link to those pages like this:

```html
<a href="pages/[your new HTML file name]">Link to new page</a>
```